##R script to download tutorial data and process it into the project folders

##Create directory structure

dir.create("Raw Data")
dir.create("Raw Data/Stats 19")
dir.create("Raw Data/Census")
dir.create("Raw Data/Spatial Data")
dir.create("Raw Data/Spatial Data/LSOA 2011")
dir.create("Raw Data/Spatial Data/OS Open Roads")


#Download and Extract Data

#Download file to Stats19 folder in Raw Data and unzip
download.file(url = "http://data.dft.gov.uk.s3.amazonaws.com/road-accidents-safety-data/Stats19_Data_2005-2014.zip", destfile = "./Raw Data/Stats 19/stats19_2005_2014.zip")
#unzip
unzip(zipfile = "./Raw Data/Stats 19/stats19_2005_2014.zip", exdir = "./Raw Data/Stats 19/unzipped")

#download pre processed census data from Github
download.file(url = "https://github.com/richfry/IPDLN/raw/master/Data/Census.zip", destfile = "./Raw Data/Census/census.zip")
#unzip
unzip(zipfile = "./Raw Data/Census/census.zip", exdir = "./Raw Data/Census/unzipped", overwrite = T)

#download census boundary data
download.file(url="https://census.edina.ac.uk/ukborders/easy_download/prebuilt/shape/Wales_lsoa_2011_gen.zip", destfile = "./Raw Data/Spatial Data/LSOA 2011/LSOA2011.zip")
#unzip
unzip(zipfile = "./Raw Data/Spatial Data/LSOA 2011/LSOA2011.zip", exdir = "./Raw Data/Spatial Data/LSOA 2011/unzipped", overwrite = T)

#download swansea area
download.file(url="https://github.com/richfry/IPDLN/raw/master/Data/swansea.lsoa.2011.zip", destfile = "./Raw Data/Spatial Data/LSOA 2011/swansea.lsoa.2011.zip")
#unzip
unzip(zipfile = "./Raw Data/Spatial Data/LSOA 2011/swansea.lsoa.2011.zip", exdir = "./Raw Data/Spatial Data/LSOA 2011/unzipped")


#download
download.file(url="https://github.com/richfry/IPDLN/raw/master/Data/OSOpenRoads.zip", destfile = "./Raw Data/Spatial Data/OS Open Roads/OSOpenRoads.zip")
#unzip
unzip(zipfile = "./Raw Data/Spatial Data/OS Open Roads/OSOpenRoads.zip", exdir = "./Raw Data/Spatial Data/OS Open Roads/unzipped")


download.file(url="https://github.com/richfry/IPDLN/raw/master/Data/roadsummary.csv", destfile = "./Raw Data/Spatial Data/OS Open Roads/road_summary.csv")

download.file(url="https://github.com/richfry/IPDLN/raw/master/Data/roadsummary_itn.csv", destfile = "./Raw Data/Spatial Data/OS Open Roads/road_summary_itn.csv")
