pkgs = c("ggplot2", "plyr", "dplyr", "GISTools", "rgdal", "rgeos", "reshape2", 
         "DT")

# check installed
new.packages <- pkgs[!(pkgs %in% installed.packages()[, "Package"])]
if (length(new.packages)) install.packages(new.packages)

# load libraries
lapply(pkgs, library, character.only = T)

## Load Stats 19 data

# load stats 19 accident into a data frame
Stats19.accidents <- read.csv(file = "./Raw Data/Stats 19/unzipped/Accidents0514.csv")

# load stats 19 casualty data into a dataframe
Stats19.casualties <- read.csv(file = "./Raw Data/Stats 19/unzipped/Casualties0514.csv")


## Load census data

census.age <- read.csv(file = "./Raw Data/Census/unzipped/age.csv")
census.sex <- read.csv(file = "./Raw Data/Census/unzipped/sex.csv")


# Load Spatial Data

# define projection
bng = "+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +datum=OSGB36 +units=m +no_defs"

# load spatial data - may take some time depending on your laptop
welsh.lsoa <- readOGR(dsn = "./Raw Data/Spatial Data/LSOA 2011/unzipped/wales_lsoa_2011_gen.shp", 
                      layer = "wales_lsoa_2011_gen", p4s = bng)

# load road summary
welsh.roads <- read.csv(file = "./Raw Data/Spatial Data/OS Open Roads/road_summary.csv")
# cast rows to columns so we have a col for each road type
welsh.roads <- dcast(welsh.roads, LSOA11CD ~ class)
# create total column
welsh.roads <- welsh.roads %>% mutate(Total_km = rowSums(.[, 2:6], na.rm = T))
# replace NAs with 0
welsh.roads[is.na(welsh.roads)] <- 0


# remove unwanted accident data

#windows
cols.to.keep = c("ï..Accident_Index", "Location_Easting_OSGR", "Location_Northing_OSGR", 
                 "Accident_Severity", "Date", "Day_of_Week", "Time", "X1st_Road_Class", "LSOA_of_Accident_Location")
#Mac Linux
cols.to.keep = c("Accident_Index", "Location_Easting_OSGR", "Location_Northing_OSGR", 
                 "Accident_Severity", "Date", "Day_of_Week", "Time", "X1st_Road_Class", "LSOA_of_Accident_Location")

Stat19.accidents.filtered <- Stats19.accidents[, cols.to.keep]
#Windows
cols.to.keep = c("ï..Accident_Index", "Age_of_Casualty", "Sex_of_Casualty")
#Mac Linux
cols.to.keep = c("Accident_Index", "Age_of_Casualty", "Sex_of_Casualty")

Stats19.casualties.filtered <- Stats19.casualties[, cols.to.keep]

# join data frames on 'ï..Accident_Index'
Stats19.final <- dplyr::left_join(Stat19.accidents.filtered, Stats19.casualties.filtered)

# filter out non Welsh LSOA codes by matching on the W of the LSOA
Stats19.final <- Stats19.final[substr(Stats19.final$LSOA_of_Accident_Location, 
                                      1, 1) == "W", ]

# quick plot to check the accidents are where we hope - i.e. Wales
qplot(data = Stats19.final, x = Stats19.final$Location_Easting_OSGR, y = Stats19.final$Location_Northing_OSGR, 
      xlab = "Eastings", ylab = "Northings") + coord_equal()


# Merge Census data
census.age.sex <- left_join(census.sex[, c("mnemonic", "Males", "Females")], 
                            census.age, by = "mnemonic")

# Create age groups by summing columns
census.final <- census.age.sex %>% mutate(children = rowSums(.[, 6:11]), adults = rowSums(.[, 
                                                                                            12:21]))
# drop unwanted cols
census.final <- census.final[, c("mnemonic", "All.usual.residents", "Males", 
                                 "Females", "children", "adults")]

#create a count of accidents by LSOA
stats19.lsoa <- Stats19.final %>% group_by(LSOA_of_Accident_Location) %>% dplyr::summarise(n_accidents = n())


# rename LSOA id cols so we can join
stats19.lsoa <- plyr::rename(stats19.lsoa, c(LSOA_of_Accident_Location = "id"))
census.final <- plyr::rename(census.final, c(mnemonic = "id"))
welsh.roads <- plyr::rename(welsh.roads, c(LSOA11CD = "id"))


# join census to accidents
injury.rates <- left_join(stats19.lsoa, census.final)
# join road data to previous table
injury.rates <- left_join(injury.rates, welsh.roads)

# rename LSOA id cols so we can join
stats19.lsoa <- plyr::rename(stats19.lsoa, c(LSOA_of_Accident_Location = "id"))
census.final <- plyr::rename(census.final, c(mnemonic = "id"))
welsh.roads <- plyr::rename(welsh.roads, c(LSOA11CD = "id"))


# join census to accidents
injury.rates <- left_join(stats19.lsoa, census.final)
# join road data to previous table
injury.rates <- left_join(injury.rates, welsh.roads)

# make the shapefile ggplot2 friendly
welsh.lsoa.fortify <- fortify(welsh.lsoa, region = "code")
# join the plot data to the injury.rates data
plot.data <- left_join(welsh.lsoa.fortify, injury.rates)

# map it!
ggplot() + geom_polygon(data = plot.data, aes(x = long, y = lat, group = group, 
                                              fill = n_accidents), colour = "grey", size = 0) + coord_equal()


# load swansea area
swansea.lsoa <- readOGR(dsn = "./Raw Data/Spatial Data/LSOA 2011/unzipped/swansea.lsoa.2011.shp", 
                        layer = "swansea.lsoa.2011", p4s = bng)

swansea.lsoa@data <- plyr::rename(swansea.lsoa@data, c(LSOA11CD = "code"))
# fortify
swansea.lsoa.fortify <- fortify(swansea.lsoa, region = "code")
# join injury rates to new geometry
plot.data <- left_join(swansea.lsoa.fortify, injury.rates)

# Map it!
ggplot() + geom_polygon(data = plot.data, aes(x = long, y = lat, group = group, 
                                              fill = n_accidents), colour = "grey", size = 0) + coord_equal() + xlab("Eastings") + 
  ylab("Northings")

# create rates
plot.data$basic.rate.pop <- plot.data$n_accidents/plot.data$All.usual.residents

# map rates to show spatial distribution
ggplot() + geom_polygon(data = plot.data, aes(x = long, y = lat, group = group, 
                                              fill = basic.rate.pop), colour = "grey", size = 0) + coord_equal() + xlab("Eastings") + 
  ylab("Northings")


# quintile for accidents
plot.data$accident.q <- cut(plot.data$n_accidents, 5, labels = c("1", "2", "3", 
                                                                 "4", "5"))
# quintile for basic pop rate
plot.data$BR.quintile <- cut(plot.data$basic.rate.pop, 5, labels = c("1", "2", 
                                                                     "3", "4", "5"))
# map it! accident
ggplot() + geom_polygon(data = plot.data, aes(x = long, y = lat, group = group, 
                                              fill = accident.q), colour = "grey", size = 0) + scale_fill_brewer(type = "seq", 
                                                                                                                 palette = "Blues") + coord_equal() + xlab("Eastings") + ylab("Northings")
# basic rates
ggplot() + geom_polygon(data = plot.data, aes(x = long, y = lat, group = group, 
                                              fill = BR.quintile), colour = "grey", size = 0) + scale_fill_brewer(type = "seq", 
                                                                                                                  palette = "Blues") + coord_equal() + xlab("Eastings") + ylab("Northings")

# create road rates
plot.data$road.rate = plot.data$n_accidents/plot.data$Total_km
# plot standard rate
ggplot() + geom_polygon(data = plot.data, aes(x = long, y = lat, group = group, 
                                              fill = road.rate), colour = "grey", size = 0) + coord_equal() + xlab("Eastings") + 
  ylab("Northings")


# create quintiles
plot.data$road.rate.q <- cut(plot.data$road.rate, 5, labels = c("1", "2", "3", 
                                                                "4", "5"))
# quintile plot
ggplot() + geom_polygon(data = plot.data, aes(x = long, y = lat, group = group, 
                                              fill = road.rate.q), colour = "grey", size = 0) + scale_fill_brewer(type = "seq", 
                                                                                                                  palette = "Blues") + coord_equal() + xlab("Eastings") + ylab("Northings")


# draw a histogram of road types in data to look at the distribution of road
# type lengths
hist.data <- tapply(melt(welsh.roads[, 1:6])$value, melt(welsh.roads[, 1:6])$variable, 
                    FUN = sum)

barplot(hist.data)

# Load data
welsh.roads.itn <- read.csv(file = "./Raw Data/Spatial Data/OS Open Roads/road_summary_itn.csv")



# draw histogram
hist.data <- tapply(welsh.roads.itn$total_length, welsh.roads.itn$descriptiveterm, 
                    FUN = sum)

barplot(hist.data)

# cross tab so road type in cols
welsh.roads.itn <- dcast(welsh.roads.itn, LSOA11CD ~ descriptiveterm)
welsh.roads.itn[is.na(welsh.roads.itn)] <- 0
# aggregate minor roads into C roads
welsh.roads.itn <- welsh.roads.itn %>% mutate(`C Road` = rowSums(.[, c("Alley", 
                                                                       "Local Street", "Minor Road", "Private Road - Publicly Accessible")]))
# subset to remove unwanted columns
welsh.roads.itn <- welsh.roads.itn[, c("LSOA11CD", "A Road", "B Road", "C Road", 
                                       "Motorway")]
# rename LOSA field to join to the stats 19 data
welsh.roads.itn <- plyr::rename(welsh.roads.itn, c(LSOA11CD = "id"))

# regroup stats19 roads so that they reflect itn create counts by road type
# per lsoa
stats19.lsoa.road <- Stats19.final %>% group_by(LSOA_of_Accident_Location, X1st_Road_Class) %>% 
  dplyr::summarise(n_accidents = n())
# crosstab so road type is cols
stats19.lsoa.road <- stats19.lsoa.road %>% dcast(., LSOA_of_Accident_Location ~ 
                                                   X1st_Road_Class)
# fill NAs with 0
stats19.lsoa.road[is.na(stats19.lsoa.road)] <- 0
# Group Road types together using table above
stats19.lsoa.road <- stats19.lsoa.road %>% mutate(n_motorway = rowSums(.[, c("2", 
                                                                             "3")]), n_A_Roads = .[, "3"], n_B_Roads = .[, "4"], n_C_Roads = rowSums(.[, 
                                                                                                                                                       c("5", "6")]))
# remove unwanted columns
stats19.lsoa.road <- stats19.lsoa.road[, c("LSOA_of_Accident_Location", "n_A_Roads", 
                                           "n_B_Roads", "n_C_Roads")]
# rename LSOA col
stats19.lsoa.road <- plyr::rename(stats19.lsoa.road, c(LSOA_of_Accident_Location = "id"))

datatable(head(stats19.lsoa.road))

# join tables
road.class.rates <- left_join(welsh.roads.itn, stats19.lsoa.road)
# create Basic Rate for calcs
road.class.rates$BasicRate <- rowSums(road.class.rates[, 5:8])/rowSums(road.class.rates[, 
                                                                                        2:4])

# create rates
road.class.rates$A_Road_Rate <- road.class.rates$n_A_Roads/(road.class.rates$`A Road` * 
                                                              road.class.rates$BasicRate)

road.class.rates$B_Road_Rate <- road.class.rates$n_B_Roads/(road.class.rates$`B Road` * 
                                                              road.class.rates$BasicRate)

road.class.rates$C_Road_Rate <- road.class.rates$n_C_Roads/(road.class.rates$`C Road` * 
                                                              road.class.rates$BasicRate)

# change inf to NA
is.na(road.class.rates) <- sapply(road.class.rates, is.infinite)
# zero out NA
road.class.rates[is.na(road.class.rates)] <- 0



# Map it!
plot.data.ar <- left_join(swansea.lsoa.fortify, road.class.rates)

ggplot() + geom_polygon(data = plot.data.ar, aes(x = long, y = lat, group = group, 
                                                 fill = A_Road_Rate), colour = "grey", size = 0) + coord_equal() + xlab("Eastings") + 
  ylab("Northings")

# Quintile
plot.data.ar$A_Road_Rate_Q <- cut(plot.data.ar$A_Road_Rate, 5, labels = c("1", 
                                                                          "2", "3", "4", "5"))

ggplot() + geom_polygon(data = plot.data.ar, aes(x = long, y = lat, group = group, 
                                                 fill = A_Road_Rate_Q), colour = "grey", size = 0) + scale_fill_brewer(type = "seq", 
                                                                                                                       palette = "Blues") + coord_equal() + xlab("Eastings") + ylab("Northings")

